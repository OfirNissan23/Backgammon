﻿namespace Backgammon.Models
{
    public class Icons
    {
        public const string Visibility_on = "\ue898";
        public const string Visibility_off = "\ue897";
        public const string IconCheckBox_off = "\ue835";
        public const string IconCheckBox_on = "\ue834";
        public const string IDCard = "\uf4ca";
        public const string Email = "\ue158";
        public const string Phone = "\ue9cd";
        public const string Location = "\uef3a";
        public const string Instagram = "\ue438";
    }
}
