﻿namespace Backgammon.Models
{
    public static class Keys
    {
        public const string NameKey = "name";
        public const string PasswordKey = "password";
        public const string EmailKey = "email";
        public const string PhoneKey = "phone";
        public const string InstagramKey = "instagram";
        public const string AddressKey = "address";
    }
}
