﻿using Backgammon.Models;
namespace Backgammon.ViewModels
{
     public class MainPageVM
     {
     }
}
