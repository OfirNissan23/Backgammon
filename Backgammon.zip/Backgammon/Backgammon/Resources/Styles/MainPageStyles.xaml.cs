namespace Backgammon.Resources.Styles;

public partial class MyStyles : ResourceDictionary
{
	public MyStyles()
	{
        InitializeComponent();
	}
}