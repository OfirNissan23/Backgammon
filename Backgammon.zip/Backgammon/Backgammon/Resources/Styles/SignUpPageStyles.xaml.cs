namespace Backgammon.Resources.Styles;

public partial class SignUpPageStyles : ResourceDictionary
{
	public SignUpPageStyles()
	{
		InitializeComponent();
	}
}