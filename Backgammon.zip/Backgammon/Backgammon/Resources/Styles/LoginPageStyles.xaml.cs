namespace Backgammon.Resources.Styles;

public partial class LoginPageStyles : ResourceDictionary
{
	public LoginPageStyles()
	{
		InitializeComponent();
	}
}