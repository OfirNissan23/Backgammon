namespace Backgammon.Resources.Styles;

public partial class Icons : ResourceDictionary
{
	public Icons()
	{
		InitializeComponent();
	}
}