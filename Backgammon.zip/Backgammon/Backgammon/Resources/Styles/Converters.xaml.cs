namespace Backgammon.Resources.Styles;
public partial class Converters : ResourceDictionary
{
	public Converters()
	{
        InitializeComponent();
	}
}